import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Load data
velocity = pd.read_csv('/home/hemanth/log_files/log_20_2025-2-28-22-56-56_vehicle_local_position_0.csv')
attitude = pd.read_csv('/home/hemanth/log_files/log_20_2025-2-28-22-56-56_vehicle_attitude_0.csv')

# Convert timestamps to seconds
velocity['timestamp'] = (velocity['timestamp'] - velocity['timestamp'].iloc[0]) * 1e-6
attitude['timestamp'] = (attitude['timestamp'] - attitude['timestamp'].iloc[0]) * 1e-6

# Plot Velocities
plt.figure(figsize=(12, 6))
plt.plot(velocity['timestamp'], velocity['vx'], label='Vx (m/s)')
plt.plot(velocity['timestamp'], velocity['vy'], label='Vy (m/s)')
plt.plot(velocity['timestamp'], velocity['vz'], label='Vz (m/s)')
plt.xlabel('Time (s)')
plt.ylabel('Velocity (m/s)')
plt.title('Velocities during Failsafe')
plt.legend()
plt.grid(True)
plt.show()

# Plot Attitudes
plt.figure(figsize=(12, 6))
plt.plot(attitude['timestamp'], np.degrees(attitude['roll']), label='Roll (°)')
plt.plot(attitude['timestamp'], np.degrees(attitude['pitch']), label='Pitch (°)')
plt.plot(attitude['timestamp'], np.degrees(attitude['yaw']), label='Yaw (°)')
plt.xlabel('Time (s)')
plt.ylabel('Angle (°)')
plt.title('Attitude Angles during Failsafe')
plt.legend()
plt.grid(True)
plt.show()

import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
file_path = "/home/hemanth/log_files/log_20_2025-2-28-22-56-56_failsafe_flags_0.csv"  # Replace with actual filename
df = pd.read_csv(file_path)

# Convert timestamp to seconds (assuming it’s in microseconds)
df["time_sec"] = df["timestamp"] / 1e6  

# Determine Failsafe Status (1 if any failsafe flag is active)
failsafe_columns = [
    "local_altitude_invalid",
    "local_position_invalid",
    "global_position_invalid",
    "offboard_control_signal_lost",
    "battery_warning",
    "geofence_breached"
]
df["failsafe_status"] = df[failsafe_columns].max(axis=1)

# Aggregate failsafe occurrences per second
failsafe_counts = df.groupby("time_sec")["failsafe_status"].sum().reset_index()

# Plot line graph
plt.figure(figsize=(8, 5))
plt.plot(failsafe_counts["time_sec"], failsafe_counts["failsafe_status"], marker='o', linestyle='-', color='teal', linewidth=2)

# Formatting the plot
plt.xlabel("Time (s)")
plt.ylabel("Failsafe Occurrences")
plt.title("Failsafe Activations Over Time")
plt.grid(True, linestyle="--", alpha=0.6)
plt.show()

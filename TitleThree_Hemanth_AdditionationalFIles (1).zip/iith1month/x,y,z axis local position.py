import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Load the data from a CSV file (replace 'data.csv' with your actual file name)
file_path = '/home/hemanth/log_files/log_19_2025-2-28-22-56-56_vehicle_local_position_0.csv'  # Update this with the correct file path
df = pd.read_csv(file_path)

# Remove non-numeric and NaN values from the dataset
df = df.replace([np.inf, -np.inf], np.nan).dropna()

# Convert timestamps to seconds (assuming timestamps are in microseconds)
df["timestamp"] = (df["timestamp"] - df["timestamp"].min()) / 1e6

# Plot x, y, z positions over time
plt.figure(figsize=(10, 5))
plt.plot(df["timestamp"], df["x"], label='X Position', color='r', marker='.')
plt.plot(df["timestamp"], df["y"], label='Y Position', color='g', marker='.')
plt.plot(df["timestamp"], df["z"], label='Z Position', color='b', marker='.')

plt.xlabel('Time (s)')
plt.ylabel('Position (m)')
plt.title('Quadrotor Position Over Time')
plt.legend()
plt.grid(True)
plt.show()

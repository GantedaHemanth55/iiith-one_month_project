
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Load the CSV file
file_path = "/home/hemanth/log_files/log_20_2025-2-28-22-56-56_vehicle_local_position_0.csv"  # Change this to your actual CSV file
df = pd.read_csv(file_path)

# Ensure timestamps are sorted
df = df.sort_values(by='timestamp')

# Find the timestamp where GPS fails (first occurrence of xy_valid = 0)
gps_failure_time = df[df['xy_valid'] == 0]['timestamp'].min()

# Separate data before and after failure
before_failure = df[df['timestamp'] < gps_failure_time]
after_failure = df[df['timestamp'] >= gps_failure_time]

# Plot 3D Trajectory
fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111, projection='3d')

# Plot before GPS failure
ax.plot(before_failure['x'], before_failure['y'], before_failure['z'], color='blue', label='Before GPS Failure')

# Plot after GPS failure
ax.plot(after_failure['x'], after_failure['y'], after_failure['z'], color='red', label='After GPS Failure')

# Labels and title
ax.set_xlabel('X Position (m)')
ax.set_ylabel('Y Position (m)')
ax.set_zlabel('Altitude (Z) (m)')
ax.set_title('3D Trajectory of Quadrotor Before and After GPS Failure')
ax.legend()

# Show the plot
plt.show()
